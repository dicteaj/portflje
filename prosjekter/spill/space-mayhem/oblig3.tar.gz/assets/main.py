import asyncio
import pygame

from sim import Simulation


async def main():
    pygame.init()

    game = Simulation()
    await game.run()


asyncio.run(main())