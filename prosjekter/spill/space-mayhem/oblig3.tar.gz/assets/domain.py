"""
Sprite klasser for alle spill-objekter i spillet.

Innholder ShipSprite, BulletSprite, MoonSprite, PlatformSprite og FuelSprite

Forfatter: Benedicte A.J. bejan0134
"""
import pygame
import math
from config import *
import random


class ShipSprite(pygame.sprite.Sprite):#pygamespritesprite er forhåndsdefinert
    """
    Representerer romskipet som spillerene kontrollerer.
    Håndterer: rotasjon, bevegelse, tyngdekraft, fuel, skyting, og holder oversikt over score og alive-status. 
    """

    def __init__(self, image_path, x, y, controls, bullet_group, screen_width, screen_height):
        """
        Initialiserer romskipet. 

        Argumenter:
        - image_path (str): sti til skipets png bilde
        - x (int): start x posisjon
        - y (int): start y posisjon
        - controls (dict): keyboard "kart" for de 4 ulike bevegelsene til skipet
        - bullet_group (group): sprite gruppe med bullets
        - screen_width (int): bredde på spill-skjermen
        - screen_height (int): høyde på spill-skjermen
        """
        super().__init__()
        self.original_image = pygame.image.load(image_path).convert_alpha()
        self.original_image = pygame.transform.scale(self.original_image, DEFAULT_SHIP_SIZE)
        self.image = self.original_image.copy()
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)
        self.angle = 0
        self.vel_x = 0.0
        self.vel_y = 0.0
        self.pos_x = float(self.rect.x)
        self.pos_y = float(self.rect.y)
        self.last_x = self.pos_x
        self.last_y = self.pos_y
        self.controls = controls
        self.bullet_group = bullet_group
        self.shoot_cooldown = 0
        self.screen_width = screen_width
        self.screen_height = screen_height
        self._score = 0 #privat
        self.alive = True
        self.fuel = START_FUEL


    @property
    def score(self):
        """
        Spillerens score
        """
        return self._score

    @score.setter
    def score(self,value):
        """
        Setter score til aldri å bli mindre enn 0.
        """
        self._score = max(0, value)


    def rotate(self, direction, dt):
        """
        Roterer skipets bilde og oppdaterer vinkel.

        Args:
        - direction (int): -1 for venstre og 1 for høyre.
        - dt (float): tid i sek siden siste frame.
        """
        self.angle += ROTATION_SPEED * direction* dt * FPS

        old_center = self.rect.center
        self.image= pygame.transform.rotate(self.original_image, -self.angle)
        self.rect = self.image.get_rect(center = old_center)

        #ny posisjon etter rotasjon:
        self.pos_x = float(self.rect.x)
        self.pos_y = float(self.rect.y)

    def thrust(self, dt):
        """
        Legger til thrust/akserelasjon i retningen til skipet.
        Bruker Fuel.

        Args:
        - dt(float): tid i sek siden siste frame.
        """
        if self.fuel > 0:
            angle = math.radians(-self.angle+90)

            self.vel_x += math.cos(angle) * THRUST * dt * FPS
            self.vel_y -= math.sin(angle) * THRUST * dt * FPS

            self.fuel = max(0, self.fuel - FUEL_PER_FRAME * dt * FPS)

    def gravity(self, dt):
        """
        Legger til en konstant tyngekraft.

        Args:
        - dt(float): tid i sek siden siste frame.
        """
        self.vel_y += GRAVITY * dt* FPS

    def fire(self):
        """
        Skyter en bullet i retningen til skipet.
        Cooldown periode for at det skal gå litt tid mellom hvert skudd (det "lades opp")
        """
        if self.shoot_cooldown == 0:
            bullet = BulletSprite(self.rect.centerx, self.rect.centery, self.angle, self.screen_width, self.screen_height, owner = self)
            self.bullet_group.add(bullet)
            self.shoot_cooldown = 20 #fps før ny skyting

    def sync_pos(self):
        """
        Sykroniserer rect med float posisjonene
        """
        self.rect.x = round(self.pos_x)
        self.rect.y = round(self.pos_y)

    def move_back(self):
        """
        FLytter skipet tilbake til siste gyldige posisjon
        """
        self.pos_x = self.last_x
        self.pos_y = self.last_y
        self.sync_pos()


    def update(self, dt):
        """
        Oppdaterer skipet i en ramme.
        Leser input fra spiller, legger til rotasjon/thrust/skyting,
        legger til tyngekraften, beveger skipet og legger til grenser.

        Args:
        - dt(float): tid i sek siden siste frame.
        """

        keys = pygame.key.get_pressed()

        #siste fyldige pos
        self.last_x = self.pos_x
        self.last_y = self.pos_y

        #rotasjon
        if keys[self.controls['left']]:
            self.rotate(-1, dt)
        if keys[self.controls['right']]:
            self.rotate(1, dt)

        #thrust
        if keys[self.controls['thrust']]:
            self.thrust(dt)

        #skyting
        if self.shoot_cooldown > 0:
            self.shoot_cooldown = max(0, self.shoot_cooldown - dt * FPS)
        
        if keys[self.controls['fire']] and self.shoot_cooldown <= 0:
            self.fire()

        #tyngdekraft
        self.gravity(dt)

        #flytt skip med float pos
        self.pos_x += self.vel_x * dt * FPS
        self.pos_y += self.vel_y * dt * FPS

        self.rect.x = round(self.pos_x)
        self.rect.y = round(self.pos_y)

        hit_wall = False

        if self.rect.left < 0:
            self.rect.left = 0
            self.pos_x = float(self.rect.x)
            self.vel_x = abs(self.vel_x) * 0.5 #0.5 er en dempningsfaktor ved kollisjon
            hit_wall = True

        elif self.rect.right > self.screen_width:
            self.rect.right = self.screen_width
            self.pos_x = float(self.rect.x)
            self.vel_x = -abs(self.vel_x) * 0.5
            hit_wall = True

        if self.rect.top < 0:
            self.rect.top = 0
            self.pos_y = float(self.rect.y)
            self.vel_y = abs(self.vel_y) * 0.5
            hit_wall = True

        elif self.rect.bottom > self.screen_height:
            self.rect.bottom = self.screen_height
            self.pos_y = float(self.rect.y)
            self.vel_y = abs(self.vel_y) * 0.5
            hit_wall = True

        if hit_wall:

            self.score += WALL_CRASH

class BulletSprite(pygame.sprite.Sprite):
    """
    Representerer et skudd/ en bullet som skytes av romskip/spillerne.
    Beveger seg i rett linje (ingen tyngekraft virker på den) i retningen til skipet.
    """

    def __init__(self, x, y, angle, screen_width, screen_height, owner):
        """
        Initialiserer bulleten med posisjon, retning og eier (hvilket skip som avfyrer).

        Args:
        - x (int): start x posisjon
        - y (int): start y posisjon
        - angle (float): vinkelen til skipet, retningen bullet skal avfyres
        - screen_width (int): bredde på spill-skjermen
        - screen_height (int): høyde på spill-skjermen
        - owner (ShipSprite): skipet som avfyrer bullet
        """
        super().__init__()
        self.owner = owner
        self.image = pygame.Surface(BULLET_SIZE)
        self.image.fill(BULLET_COLOR)
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)

        self.pos_x = float(self.rect.x)
        self.pos_y = float(self.rect.y)

        self.screen_width = screen_width
        self.screen_height = screen_height

        angle = math.radians(-angle + 90)
        self.vel_x = math.cos(angle) * BULLET_SPEED
        self.vel_y = -math.sin(angle) * BULLET_SPEED

    def update(self, dt):
        """
        Beveger bullet og fjerner hvis den forlater skjermen.
        """
        self.pos_x += self.vel_x * dt* FPS
        self.pos_y += self.vel_y * dt * FPS

        self.rect.x = round(self.pos_x)
        self.rect.y = round(self.pos_y)

        if (self.rect.right <0 or self.rect.left > self.screen_width or self.rect.bottom<0 or self.rect.top > self.screen_height):
            self.kill()

class MoonSprite(pygame.sprite.Sprite):
    """
    Representerer en måne/obstacle.
    Opprettes på tilfeldig sted og i tilfeldig størrelse. 
    Bullets fjernes hvis de treffer måne, og skip blir dyttet vekk hvis de kjører inn i den.
    """

    def __init__(self, screen_width, screen_height):
        """
        Initialiserer månen på tilfeldig sted og tilfeldig størrelse.

        Args:
        - screen_width (int): bredde på spill-skjermen
        - screen_height (int): høyde på spill-skjermen
        """
        super().__init__()
        self.size = random.randint(60,180)
        self.radius = self.size//2
        self.image = pygame.image.load(MOON).convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.size, self.size))
        self.rect = self.image.get_rect()
        self.rect.center = (random.randint(0+self.size, screen_width-self.size),random.randint(0+self.size, screen_height-self.size))


class PlatformSprite(pygame.sprite.Sprite):
    """
    Representerer ladeplatformen til skipene.

    """

    def __init__(self, x, y ):
        """
        Initialiserer platformen på gitt posisjon.

        Args:
        - x (int): x posisjon til platform (sentrum av plattform)
        - y (int): y posisjon til platform (sentrum av plattform)
        """
        super().__init__()
        self.image = pygame.Surface((300,60))
        self.image.fill(PLATFORM_COLOR)
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)

class FuelSprite(pygame.sprite.Sprite):
    """
    Representerer fuel som kan fanges av spillere.
    Spawner på tilfeldig posisjon, og fanges når spiller flyr på den.
    Nye dukker opp hvert 20 sekund.
    """

    def __init__(self, screen_width, screen_height):
        """
        Initialiserer fuel-hjerter på tilfeldig posisjon.
        
        Args:
        - screen_width (int): bredde på spill-skjermen
        - screen_height (int): høyde på spill-skjermen
        """
        super().__init__()
        self.image = pygame.image.load(HEART).convert_alpha()
        self.image = pygame.transform.scale(self.image, HEART_SIZE)
        self.rect = self.image.get_rect()
        self.rect.center = (random.randint(50, screen_width-50), random.randint(50, screen_height-50))