"""
Simulation og hovedløkken for spillet. 
Initialiserer, har styr på sprites, kollisjons-logikk, og å rendere spillet.

Forfatter: Benedicte A.J. bejan0134
"""

import pygame
from config import *
from domain import *
import os
import random
import math
import asyncio

class Simulation():
    """
    Hovedklassen som eier og koordinerer alle spille-objektene.
    """
    def __init__(self):
        """
        Initialiserer pygame, skjermen, alle sprites og gamestate.
        Lager to skip, tilfeldig tall (mellom 3-5) måner/obstacles, to ladeplattformer og det første settet med fuel/hjerter.
        """

        pygame.init()

        #pygame.mixer.music.load(MUSIC)
        #pygame.mixer.music.play(-1)#loop

        #Følgende 3 linjer med kode er hentet fra https://youtu.be/GX_fsDz4j8A?si=kzWCNhMeePP1RlqA
        os.environ['SDL_VIDEO_CENTERED']='1'
        info = pygame.display.Info()
        self.screen_width = 1100
        self.screen_height = 700

        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Space Mayhem")
        self.clock = pygame.time.Clock()
        self.bullets = pygame.sprite.Group()
        self.ship1 = ShipSprite(SHIP1, (self.screen_width//4), (self.screen_height//5*4), SHIP1_CONTROLS, self.bullets, self.screen_width, self.screen_height)
        self.ship2 = ShipSprite(SHIP2, (self.screen_width//4*3), (self.screen_height//5*4), SHIP2_CONTROLS, self.bullets, self.screen_width, self.screen_height)

        self.all_sprites = pygame.sprite.Group()
        self.all_sprites.add(self.ship1, self.ship2)

        self.platforms = pygame.sprite.Group()
        platform1 = PlatformSprite(self.screen_width //4, self.screen_height//5*4+(2130/16))
        platform2 = PlatformSprite(self.screen_width //4*3, self.screen_height//5*4+(2130/16))
        self.platforms.add(platform1, platform2)
        self.all_sprites.add(platform1, platform2)

        self.moons = pygame.sprite.Group()
        number = random.randint(3,5)
        for i in range(0,number):
            moon = self.make_moon()
            self.moons.add(moon)
            self.all_sprites.add(moon)

        self.font = pygame.font.SysFont(None, 50)

        self.game_over = False
        #self.restart = False
        self.winner_ship = None

        self.hearts = pygame.sprite.Group()
        self.heart_timer = 0
        self.spawn_hearts()

    def make_moon(self):
        """
        Lager måne på tilfeldig posisjon som ikke allerede er "opptatt"
        Returnerer en MoonSprite i gyldig posisjon.
        """
        while True:
            moon = MoonSprite(self.screen_width, self.screen_height)

            ship_collision = pygame.sprite.spritecollide(moon, pygame.sprite.Group(self.ship1, self.ship2), False, pygame.sprite.collide_circle)
            moon_collision = pygame.sprite.spritecollide(moon, self.moons, False, pygame.sprite.collide_circle)
            platform_collision = pygame.sprite.spritecollide(moon, self.platforms, False)
            
            if not ship_collision and not moon_collision and not platform_collision:
                return moon

    def collisions(self):
        """
        Sjekker etter kollisjoner hver frame og oppdaterer scores/fuel/velocity.

        Håndterer kollisjoner mellom: skip-måne, måne-bullet, 
        bullet-skip, skip-skip, skip-platform, og skip-fuel.
        """
        for ship in [self.ship1, self.ship2]:
            hits = pygame.sprite.spritecollide(ship, self.bullets, False) 
            for bullet in hits:
                if bullet.owner != ship:
                    bullet.owner.score += SCORE_KILL
                    bullet.kill()

        #Måne og bullets
        pygame.sprite.groupcollide(self.moons, self.bullets, False, True)
        
        #Måne og skip
        for ship in [self.ship1, self.ship2]:
            hits = pygame.sprite.spritecollide(ship, self.moons, False, pygame.sprite.collide_circle)
            
            if hits:
                ship.move_back()
                ship.vel_x *= -0.5
                ship.vel_y *= -0.5
                ship.score += SCORE_CRASH

            #sjekk fuel
            if ship.fuel <= 0 and ship.alive:
                ship.alive = False
                ship.fuel = 0
                ship.kill()

        #skip og skip
        if pygame.sprite.collide_circle(self.ship1, self.ship2):
            self.ship1.move_back()
            self.ship2.move_back()

            self.ship1.vel_x *= -0.5
            self.ship1.vel_y *= -0.5
            self.ship2.vel_x *= -0.5
            self.ship2.vel_y *= -0.5  

            self.ship1.score += SCORE_CRASH
            self.ship2.score += SCORE_CRASH

        #refueling på platform
        for ship in [self.ship1, self.ship2]:
            hits = pygame.sprite.spritecollide(ship, self.platforms, False)
            for platform in hits:
                ship.rect.bottom = platform.rect.top
                ship.pos_x = float(ship.rect.x)
                ship.pos_y = float(ship.rect.y)
                ship.fuel = min(ship.fuel + REFUEL_RATE, START_FUEL)
                ship.vel_x = 0
                ship.vel_y = 0
        
        for ship in [self.ship1, self.ship2]:
            if not ship.alive and not self.game_over:
                self.game_over = True
    
    def scores(self):
        """
        Tegner en score for hver av spillerne.
        """
        #Player 1 score (venstre)
        text1 = self.font.render(f"Team Pink Score: {self.ship1.score}", True, SCORE_PINK_COLOR)
        self.screen.blit(text1, (20,20))
        #Player 2 score (høyre)
        text2 = self.font.render(f"Team Purple Score: {self.ship2.score}", True, SCORE_PURPLE_COLOR)
        self.screen.blit(text2, (self.screen_width - 500,20))

        self.fuel_bar(self.ship1, 20,60)
        self.fuel_bar(self.ship2, self.screen_width-500,60)


    def fuel_bar(self, ship, x, y):
        """
        Tegner en fuel bar for et skip på gitt posisjon.
        
        Args:
        - ship (ShipSprite): skipet som vi skal vise fuel-nivå av.
        - x (int): x posisjon til fuel bar på skjermen
        - y (int): y posisjon til fuel bar på skjermen
        """
        pygame.draw.rect(self.screen, FUEL_BAR_COLOR, (x,y, FUEL_BAR_W, FUEL_BAR_H))

        fill = int ((ship.fuel / START_FUEL) * FUEL_BAR_W)

        if ship.fuel > START_FUEL * 0.5:
            color = GREEN #grønn over 50% fuel
        elif ship.fuel > START_FUEL * 0.25:
            color = YELLOW #yellow over 25% fuel
        else:
            color = RED #lavt fuel (under 25%)

        pygame.draw.rect(self.screen, color, (x,y, fill, FUEL_BAR_H))
        pygame.draw.rect(self.screen, WHITE, (x,y, FUEL_BAR_W, FUEL_BAR_H), 2)


    def spawn_hearts(self):
        """
        Fjerner eksisterende hjerter og oppretter nye.
        Har 100 forsøk på å opprette 3 hjerter på tilfeldig ledig posisjon.
        """
        for heart in self.hearts.sprites():
            heart.kill()

        self.hearts.empty()

        attempts= 0
        while len(self.hearts) < 3 and attempts <100:
            heart = FuelSprite(self.screen_width, self.screen_height)
            collision = pygame.sprite.spritecollide(heart, self.all_sprites, False)
            if not collision:
                self.hearts.add(heart)
                self.all_sprites.add(heart)
            attempts+=1
        
    def heart_collide(self):
        """
        Sjekker om skip har hentet hjerte, og skip får så en fuel-boost.
        """
        for ship in [self.ship1, self.ship2]:
            hits = pygame.sprite.spritecollide(ship, self.hearts, True)
            for i in hits:
                ship.fuel = min(ship.fuel+FUEL_BOOST, START_FUEL)

    def check_score(self):
        """
        Sjekker om en av spillerene har score over max score for å vinne.
        Hvis det er sant setter det at game over er sant.
        """
        if self.ship1.score >= WINNING_SCORE:
            self.winner_ship = self.ship1
            self.game_over = True

        if self.ship2.score >= WINNING_SCORE:
            self.winner_ship = self.ship2
            self.game_over = True

    async def winner(self):
        """
        Viser "game over" overlay når en spiller har vunnet eller er død.
        Viser hvem som varnt og scores til hver spiller.
        Blokkerer frem til ESC/vindu lukkes.
        """
        if self.winner_ship == self.ship1:
            w_text = "Winner: TEAM PINK!"
            w_color = PINK
        elif self.winner_ship == self.ship2:
            w_text = "Winner: TEAM PURPLE!"
            w_color = PURPLE
        elif not self.ship2.alive:
            w_text = "Winner: TEAM PINK!"
            w_color = PINK
        elif not self.ship1.alive:
            w_text = "Winner: TEAM PURPLE!"
            w_color = PURPLE
        else:
            w_text = "It's a draw!"
            w_color = WHITE
        overlay = pygame.Surface((self.screen_width, self.screen_height))
        overlay.set_alpha(180)
        overlay.fill(BLACK)
        self.screen.blit(overlay, (0,0))

        font = pygame.font.SysFont(None, 100)
        winner_text = font.render(w_text, True, w_color)
        winner_rect = winner_text.get_rect(center=(self.screen_width//2, self.screen_height//2))
        self.screen.blit(winner_text, winner_rect)

        score_font = pygame.font.SysFont(None, 50)
        score1 = score_font.render(f"Team Purple Score: {self.ship2.score}", True, PURPLE)
        score2 = score_font.render(f"Team Pink Score: {self.ship1.score}", True, PINK)
        self.screen.blit(score1, score1.get_rect(center=(self.screen_width//2, self.screen_height//10*8)))
        self.screen.blit(score2, score1.get_rect(center=(self.screen_width//2, self.screen_height//10*7)))

        quit_t = self.font.render("Press ECS to quit", True, RED)        
        #restart_t = sef.fond.render("Press R to restart", True, GREEN)
        self.screen.blit(quit_t, quit_t.get_rect(center=(self.screen_width//2, self.screen_height//10*2)))
        #self.screen.blit(restart_t, restart_t.get_rect(center=(self.screen_width//2, self.screen_height//10*3)))

        pygame.display.flip()
        
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        #self.restart = False
                        return
                    #if event.key == pygame.K_r:
                    #    self.restart = True
                    #    return

            self.clock.tick(FPS)
            await asyncio.sleep(0)


    async def run(self):
        """
        Main Loop: Starter og kjører spillet.

        Håndterer input, oppdaterer alle sprites, ser på kollisjoner,
        hjerter/fuel oppdateres etter tid,, og tegner alt hver frame. 

        Avslutter når ESC trykkes eller når vindu lukkes.
        """
        while True:
            
            dt = self.clock.tick(FPS) / 1000.0 #seks siden siste frame

            if self.game_over:
                await self.winner()
                return

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        return

            self.heart_timer += dt
            if self.heart_timer >= 20: #nye hjerter hver 20 sekund
                self.heart_timer = 0
                self.spawn_hearts()
            self.heart_collide()

            self.all_sprites.update(dt)
            self.bullets.update(dt)
            self.collisions()
            self.check_score()

            self.screen.fill(SCREEN_COLOR)
            self.all_sprites.draw(self.screen)
            self.bullets.draw(self.screen)
            self.scores()
            pygame.display.flip()
            await asyncio.sleep(0) #gir kontroll tilbake til nettleseren hver frame.


