# Space Mayhem Game

## About
The game has two players with their own controls, both ships can thrust forward, rotate and shoot. Obstacles are generated, and ships can collide with walls, moons and wach other, as well as bullets. The players score is shown on the screen. Fuel decreases with thrust and can recharge by landing on the platform or by collecting fuel hearts. One player gets points by shoting the other. The game ends when one of the players win by getting a score of 1000, or if one ship runs out of fuel and dies, a gameover-screen is then shown. 

## Requirements
Pygame
Install pygame with: pip install pygame

## How to run
from the src folder: python sim.py

## How to play
Rules:
- Each player controls one spaceship (pink or purple).
- Players loose point when colliding with walls and moons.
- Players gain points by shooting the opponent.
- If ships collide, both players loose points. 
- Fuel is limited, and can be replenished by landing on the platform or by collecting hearts.
- Game ends when one player hits a score of 1000 or a player runs out of fuel. 

Player Pink controls:
- A: rotate left
- D: rotate right
- W: thrust
- S: shoot

Player Purple controls:
- Left: rotate left
- Right: rotate right
- Up: thrust
- Down: shoot

