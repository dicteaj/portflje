"""
Globale konstanter for spillet. 
Inneholder parametere som kan endres, slik som fysikken, 
instillinger i spillet, og kontroller.

Forfatter: Benedicte A.J. bejan0134
"""
import pygame

#Fysikk
GRAVITY = 0.05
THRUST = 0.08
ROTATION_SPEED = 2
BULLET_SPEED = 7

#Settinger for spiller
FPS = 60
START_FUEL = 1000
FUEL_BOOST = 500
FUEL_PER_FRAME = 1
SCORE_KILL = +100
SCORE_CRASH = -1
WALL_CRASH = -1
REFUEL_RATE = 100
WINNING_SCORE = 1000

#Bilder
HEART = "bilder/heart.png"
MOON = "bilder/moon.png"
SHIP1= "bilder/ship1.png"
SHIP2= "bilder/ship2.png"

#sang
MUSIC = "lyd/sang.ogg"

#Skjermen 
SCREEN_COLOR = (225, 210, 237) #light pink/purple
FUEL_BAR_W = 200
FUEL_BAR_H = 20
FUEL_BAR_COLOR = (58, 36, 59) #dark purple
PLATFORM_COLOR = (58, 36, 59) #dark purple
HEART_SIZE = (20,20)
BULLET_SIZE = (10,10)

#Farger
BULLET_COLOR = (205,127,50) #bronze
SCORE_PINK_COLOR = (214, 32, 78) #clear red-pink
SCORE_PURPLE_COLOR = (58, 36, 59) #endre?
YELLOW = (225,225,0)
RED = (255,0,0)
GREEN = (0,255,0)
WHITE = (255,255,255)
PINK = (255, 102, 178)
PURPLE = (153,51,255)
BLACK = (0,0,0)

#Spiller Spawn
#PLAYER1_X = 600
#PLAYER1_Y = 500
#PLAYER2_X = 200
#PLAYER2_Y = 500
DEFAULT_SHIP_SIZE = (1522/20,2130/20)

#Player 2 kontroller
SHIP2_CONTROLS = {
    'left': pygame.K_LEFT,
    'right': pygame.K_RIGHT,
    'thrust': pygame.K_UP,
    'fire': pygame.K_DOWN
}

#Player 1 kontroller
SHIP1_CONTROLS = {
    'left': pygame.K_a,
    'right': pygame.K_d,
    'thrust': pygame.K_w,
    'fire': pygame.K_s
}
